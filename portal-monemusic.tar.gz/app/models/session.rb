class Session < ApplicationRecord
  # ActiveRecord session store model
end