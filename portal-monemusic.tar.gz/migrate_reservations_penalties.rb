#!/usr/bin/env ruby
require 'sqlite3'
require 'pg'
require 'date'

# SQLite 연결 (백업 파일 사용)
sqlite_db = SQLite3::Database.new('storage/practice_backup_20250905.sqlite3')
sqlite_db.results_as_hash = true

# PostgreSQL 연결
pg_conn = PG.connect(
  host: 'localhost',
  port: 5432,
  dbname: 'portal_monemusic',
  user: 'monemusic',
  password: '5dnjfdjr1!'
)

puts "=== Reservations 마이그레이션 시작 ==="

# rooms 테이블 먼저 확인/생성
rooms_exist = pg_conn.exec("SELECT COUNT(*) FROM rooms").first['count'].to_i
if rooms_exist == 0
  puts "Rooms 테이블이 비어있음. Rooms 먼저 마이그레이션..."
  
  sqlite_db.execute("SELECT * FROM rooms") do |row|
    begin
      pg_conn.exec_params(
        "INSERT INTO rooms (id, name, description, capacity, location, amenities, image_url, created_at, updated_at) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (id) DO NOTHING",
        [
          row['id'],
          row['name'] || "Room #{row['id']}",
          row['description'],
          row['capacity'] || 1,
          row['location'],
          row['amenities'],
          row['image_url'],
          row['created_at'] || Time.now.to_s,
          row['updated_at'] || Time.now.to_s
        ]
      )
    rescue => e
      puts "Room #{row['id']} 추가 실패: #{e.message}"
    end
  end
  puts "Rooms 마이그레이션 완료"
end

# Reservations 마이그레이션
reservation_count = 0
sqlite_db.execute("SELECT * FROM reservations") do |row|
  begin
    # user_id가 존재하는지 확인
    user_exists = pg_conn.exec_params("SELECT COUNT(*) FROM users WHERE id = $1", [row['user_id']]).first['count'].to_i
    next if user_exists == 0
    
    # room_id가 존재하는지 확인
    room_exists = pg_conn.exec_params("SELECT COUNT(*) FROM rooms WHERE id = $1", [row['room_id']]).first['count'].to_i
    next if room_exists == 0
    
    # date와 시간 정보를 합쳐서 timestamp 형식으로 변환
    start_datetime = row['date'] && row['start_time'] ? "#{row['date']} #{row['start_time']}" : nil
    end_datetime = row['date'] && row['end_time'] ? "#{row['date']} #{row['end_time']}" : nil
    
    pg_conn.exec_params(
      "INSERT INTO reservations (id, user_id, room_id, start_time, end_time, status, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (id) DO NOTHING",
      [
        row['id'],
        row['user_id'],
        row['room_id'],
        start_datetime,
        end_datetime,
        row['status'] || 'pending',
        row['created_at'] || Time.now.to_s,
        row['updated_at'] || Time.now.to_s
      ]
    )
    reservation_count += 1
  rescue => e
    puts "Reservation #{row['id']} 추가 실패: #{e.message}"
  end
end

puts "Reservations 마이그레이션 완료: #{reservation_count}개"

puts "\n=== Penalties 마이그레이션 시작 ==="

# Penalties 마이그레이션
penalty_count = 0
sqlite_db.execute("SELECT * FROM penalties") do |row|
  begin
    # user_id가 존재하는지 확인
    user_exists = pg_conn.exec_params("SELECT COUNT(*) FROM users WHERE id = $1", [row['user_id']]).first['count'].to_i
    next if user_exists == 0
    
    pg_conn.exec_params(
      "INSERT INTO penalties (id, user_id, month, year, no_show_count, cancel_count, is_blocked, created_at, updated_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       ON CONFLICT (id) DO NOTHING",
      [
        row['id'],
        row['user_id'],
        row['month'] || Date.today.month,
        row['year'] || Date.today.year,
        row['no_show_count'] || 0,
        row['cancel_count'] || 0,
        row['is_blocked'] == 1 || row['is_blocked'] == 't' ? true : false,
        row['created_at'] || Time.now.to_s,
        row['updated_at'] || Time.now.to_s
      ]
    )
    penalty_count += 1
  rescue => e
    puts "Penalty #{row['id']} 추가 실패: #{e.message}"
  end
end

puts "Penalties 마이그레이션 완료: #{penalty_count}개"

# 시퀀스 업데이트
['reservations', 'penalties', 'rooms'].each do |table|
  max_id = pg_conn.exec("SELECT COALESCE(MAX(id), 0) FROM #{table}").first['coalesce'].to_i
  pg_conn.exec("SELECT setval('#{table}_id_seq', #{max_id + 1}, false)")
end

# 최종 카운트
final_reservation_count = pg_conn.exec("SELECT COUNT(*) FROM reservations").first['count']
final_penalty_count = pg_conn.exec("SELECT COUNT(*) FROM penalties").first['count']
final_room_count = pg_conn.exec("SELECT COUNT(*) FROM rooms").first['count']

puts "\n=== 마이그레이션 완료 ==="
puts "Rooms: #{final_room_count}개"
puts "Reservations: #{final_reservation_count}개"
puts "Penalties: #{final_penalty_count}개"

sqlite_db.close
pg_conn.close