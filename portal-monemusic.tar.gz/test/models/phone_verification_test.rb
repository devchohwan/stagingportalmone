require "test_helper"

class PhoneVerificationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
