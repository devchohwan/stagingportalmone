puts "=== Development 데이터를 Practice/Makeup DB로 복사 ==="

# Development 사용자들을 가져옴
dev_users = User.all.to_a

puts "Development DB 사용자 수: #{dev_users.count}"

# Practice DB에 복사
puts "\n=== Practice DB로 복사 시작 ==="
practice_config = Rails.configuration.database_configuration["practice"]["primary"]
ActiveRecord::Base.establish_connection(practice_config)

dev_users.each do |user|
  begin
    existing = User.find_by(id: user.id)
    if existing
      puts "Practice DB: #{user.username} 이미 존재"
    else
      User.create!(
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        phone: user.phone,
        password_digest: user.password_digest,
        status: user.status,
        is_admin: user.is_admin,
        teacher: user.teacher,
        created_at: user.created_at,
        updated_at: user.updated_at
      )
      puts "Practice DB: #{user.username} 복사 완료"
    end
  rescue => e
    puts "Practice DB: #{user.username} 복사 실패 - #{e.message}"
  end
end

puts "Practice DB 총 사용자: #{User.count}"

# Makeup DB에 복사
puts "\n=== Makeup DB로 복사 시작 ==="
makeup_config = Rails.configuration.database_configuration["makeup"]["primary"]
ActiveRecord::Base.establish_connection(makeup_config)

dev_users.each do |user|
  begin
    existing = User.find_by(id: user.id)
    if existing
      puts "Makeup DB: #{user.username} 이미 존재"
    else
      User.create!(
        id: user.id,
        username: user.username,
        name: user.name,
        email: user.email,
        phone: user.phone,
        password_digest: user.password_digest,
        status: user.status,
        is_admin: user.is_admin,
        teacher: user.teacher,
        created_at: user.created_at,
        updated_at: user.updated_at
      )
      puts "Makeup DB: #{user.username} 복사 완료"
    end
  rescue => e
    puts "Makeup DB: #{user.username} 복사 실패 - #{e.message}"
  end
end

puts "Makeup DB 총 사용자: #{User.count}"

puts "\n=== 복사 완료 ==="