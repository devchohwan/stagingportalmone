#!/usr/bin/env ruby
require 'sqlite3'
require 'pg'

# SQLite connection
sqlite_db = SQLite3::Database.new('storage/development.sqlite3')
sqlite_db.results_as_hash = true

# PostgreSQL connection
pg_conn = PG.connect(
  host: 'localhost',
  port: 5432,
  dbname: 'portal_monemusic',
  user: 'monemusic',
  password: '5dnjfdjr1!'
)

puts "Connected to both databases successfully!"

# Get all users from SQLite
users = sqlite_db.execute("SELECT * FROM users")
puts "Found #{users.length} users in SQLite"

# Migrate users to PostgreSQL
users.each do |user|
  begin
    # Check if user already exists by ID
    result = pg_conn.exec_params(
      "SELECT id FROM users WHERE id = $1",
      [user['id']]
    )
    
    if result.ntuples > 0
      puts "User ID #{user['id']} already exists, skipping..."
      next
    end
    
    # Insert user
    pg_conn.exec_params(
      "INSERT INTO users (id, username, name, email, phone, password_digest, status, is_admin, teacher, created_at, updated_at) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)",
      [
        user['id'],
        user['username'] || user['email']&.split('@')&.first || "user#{user['id']}",
        user['name'] || '',
        user['email'],
        user['phone_number'] || user['phone'],
        user['password_digest'] || user['encrypted_password'],
        'active',
        user['role'] == 'admin' || user['is_admin'] == 1,
        user['teacher'],
        user['created_at'] || Time.now.to_s,
        user['updated_at'] || Time.now.to_s
      ]
    )
    puts "Migrated user: #{user['email']}"
  rescue => e
    puts "Error migrating user #{user['email']}: #{e.message}"
  end
end

# Update sequence to continue from the highest ID
max_id_result = pg_conn.exec("SELECT MAX(id) FROM users")
max_id = max_id_result[0]['max'].to_i
if max_id > 0
  pg_conn.exec("SELECT setval('users_id_seq', #{max_id})")
  puts "Updated users sequence to #{max_id}"
end

# Get all rooms from SQLite
rooms = sqlite_db.execute("SELECT * FROM rooms")
puts "\nFound #{rooms.length} rooms in SQLite"

# Migrate rooms to PostgreSQL
rooms.each do |room|
  begin
    # Check if room already exists
    result = pg_conn.exec_params(
      "SELECT id FROM rooms WHERE name = $1",
      [room['name']]
    )
    
    if result.ntuples > 0
      puts "Room #{room['name']} already exists, skipping..."
      next
    end
    
    # Insert room
    pg_conn.exec_params(
      "INSERT INTO rooms (id, name, capacity, created_at, updated_at) 
       VALUES ($1, $2, $3, $4, $5)",
      [
        room['id'],
        room['name'],
        room['capacity'] || 1,
        room['created_at'] || Time.now.to_s,
        room['updated_at'] || Time.now.to_s
      ]
    )
    puts "Migrated room: #{room['name']}"
  rescue => e
    puts "Error migrating room #{room['name']}: #{e.message}"
  end
end

# Update sequence for rooms
max_id_result = pg_conn.exec("SELECT MAX(id) FROM rooms")
max_id = max_id_result[0]['max'].to_i
if max_id > 0
  pg_conn.exec("SELECT setval('rooms_id_seq', #{max_id})")
  puts "Updated rooms sequence to #{max_id}"
end

# Get all reservations from SQLite
reservations = sqlite_db.execute("SELECT * FROM reservations")
puts "\nFound #{reservations.length} reservations in SQLite"

# Migrate reservations to PostgreSQL
reservations.each do |reservation|
  begin
    # Check if reservation already exists
    result = pg_conn.exec_params(
      "SELECT id FROM reservations WHERE id = $1",
      [reservation['id']]
    )
    
    if result.ntuples > 0
      puts "Reservation #{reservation['id']} already exists, skipping..."
      next
    end
    
    # Insert reservation
    pg_conn.exec_params(
      "INSERT INTO reservations (id, user_id, room_id, date, start_time, end_time, created_at, updated_at, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)",
      [
        reservation['id'],
        reservation['user_id'],
        reservation['room_id'],
        reservation['date'],
        reservation['start_time'],
        reservation['end_time'],
        reservation['created_at'] || Time.now.to_s,
        reservation['updated_at'] || Time.now.to_s,
        reservation['status'] || 'confirmed'
      ]
    )
    puts "Migrated reservation: #{reservation['id']}"
  rescue => e
    puts "Error migrating reservation #{reservation['id']}: #{e.message}"
  end
end

# Update sequence for reservations
max_id_result = pg_conn.exec("SELECT MAX(id) FROM reservations")
max_id = max_id_result[0]['max'].to_i
if max_id > 0
  pg_conn.exec("SELECT setval('reservations_id_seq', #{max_id})")
  puts "Updated reservations sequence to #{max_id}"
end

sqlite_db.close
pg_conn.close

puts "\nMigration completed!"
puts "Please verify the data in PostgreSQL"