require 'sqlite3'
require 'bcrypt'

puts "Starting Practice to Portal migration..."

# 데이터베이스 연결
practice_db = SQLite3::Database.new('/home/cho/practice_backup_20250905.sqlite3')
practice_db.results_as_hash = true

# 현재 Portal DB 백업
system("cp storage/development.sqlite3 storage/development_before_migration_#{Time.now.strftime('%Y%m%d_%H%M%S')}.sqlite3")

# 기존 데이터 삭제 (admin 제외)
puts "\n=== Cleaning existing data (keeping admin) ==="
User.where.not(username: 'admin').destroy_all
Reservation.destroy_all
Room.destroy_all
Penalty.destroy_all

# 1. Rooms 마이그레이션
puts "\n=== Migrating Rooms ==="
practice_db.execute("SELECT * FROM rooms") do |row|
  room = Room.new(
    id: row['id'],
    number: row['number'],
    has_outlet: row['has_outlet'],
    name: "연습실 #{row['number']}",
    capacity: 4,
    description: row['has_outlet'] ? "콘센트 있음" : "콘센트 없음",
    created_at: row['created_at'],
    updated_at: row['updated_at']
  )
  room.save!(validate: false)
  puts "  Room ##{room.number} migrated"
end

# 2. Users 마이그레이션 (admin 제외)
puts "\n=== Migrating Users ==="
practice_db.execute("SELECT * FROM users WHERE username != 'admin' OR username IS NULL") do |row|
  # encrypted_password를 password_digest로 변환
  # Devise의 encrypted_password는 이미 bcrypt 해시이므로 그대로 사용
  password_digest = row['encrypted_password']
  
  # phone 컬럼이 Practice DB에 없으므로 null로 처리
  user = User.new(
    id: row['id'],
    username: row['username'] || row['email']&.split('@')&.first || "user#{row['id']}",
    name: row['name'] || row['username'] || 'Unknown',
    email: row['email'],
    phone: nil, # Practice DB에는 phone이 없음
    password_digest: password_digest || BCrypt::Password.create('password123'),
    status: row['status'] || 'approved',
    is_admin: row['is_admin'] || false,
    teacher: row['teacher'],
    created_at: row['created_at'],
    updated_at: row['updated_at']
  )
  
  begin
    user.save!(validate: false)
    puts "  User #{user.username} (#{user.name}) migrated"
  rescue => e
    puts "  Error migrating user #{row['id']}: #{e.message}"
  end
end

# 3. Reservations 마이그레이션
puts "\n=== Migrating Reservations ==="
practice_db.execute("SELECT * FROM reservations") do |row|
  # user_id와 room_id가 유효한지 확인
  user = User.find_by(id: row['user_id'])
  room = Room.find_by(id: row['room_id'])
  
  if user && room
    reservation = Reservation.new(
      id: row['id'],
      user_id: row['user_id'],
      room_id: row['room_id'],
      start_time: row['start_time'],
      end_time: row['end_time'],
      status: row['status'] || 'active',
      created_at: row['created_at'],
      updated_at: row['updated_at']
    )
    reservation.save!(validate: false)
    puts "  Reservation ##{reservation.id} (User: #{user.username}, Room: #{room.number}) migrated"
  else
    puts "  Skipped reservation #{row['id']} - User or Room not found"
  end
end

# 4. Penalties 마이그레이션
puts "\n=== Migrating Penalties ==="
practice_db.execute("SELECT * FROM penalties") do |row|
  user = User.find_by(id: row['user_id'])
  
  if user
    penalty = Penalty.new(
      id: row['id'],
      user_id: row['user_id'],
      month: row['month'],
      year: row['year'],
      no_show_count: row['no_show_count'] || 0,
      cancel_count: row['cancel_count'] || 0,
      is_blocked: row['is_blocked'] || false,
      created_at: row['created_at'],
      updated_at: row['updated_at']
    )
    penalty.save!(validate: false)
    puts "  Penalty for User #{user.username} (#{row['year']}/#{row['month']}) migrated"
  else
    puts "  Skipped penalty #{row['id']} - User not found"
  end
end

# 결과 요약
puts "\n=== Migration Summary ==="
puts "Rooms: #{Room.count}"
puts "Users: #{User.count} (including admin)"
puts "Reservations: #{Reservation.count}"
puts "Penalties: #{Penalty.count}"

puts "\n✅ Migration completed successfully!"
puts "Backup saved as: storage/development_before_migration_*.sqlite3"