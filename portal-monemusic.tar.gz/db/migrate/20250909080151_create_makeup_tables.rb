class CreateMakeupTables < ActiveRecord::Migration[8.0]
  def change
    # This migration is no longer needed after merging PT and Makeup into Portal
    # Keeping it empty to maintain migration history
  end
end